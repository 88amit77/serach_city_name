from django.conf.urls import url
from main import views
from django.urls import path

urlpatterns = [
  # path("",views.home,name='home'),

  path('', views.search, name='search'),
]


