from django.shortcuts import render
import csv,io
from django.contrib import messages
from django.http import HttpResponse,HttpResponseRedirect
from django.db.models import Q


# Create your views here.
# def home(request):
#     return render(request, 'main/index.html')
def search(request):
  if request.method=='POST':
     srch =request.POST['srh']   
     
     if srch:
        match=student.objects.filter(Q(name__icontains=srch))

        if match:
            return render(request,'search.html',{'sr':match})
        else:
            message.error(request,'no result found')
     else:
        return HttpResponseRedirect('/search/')
  
  return render(request,'search.html')           